/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.exemplo.rest.dto;

import jakarta.ws.rs.core.Response.Status;
import java.sql.Date;

/**
 *
 * @author Beatr
 */
public class ExceptionResponse {
    
    private String message;
    private Date dtException;
    private String path;
    private Status httpStatus;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getDtException() {
        return dtException;
    }

    public void setDtException(Date dtException) {
        this.dtException = dtException;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Status getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(Status httpStatus) {
        this.httpStatus = httpStatus;
    }
    
}
