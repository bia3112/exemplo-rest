package br.unipar.exemplo.rest.controllers;

import br.unipar.exemplo.rest.dto.ClienteFindAllResponse;
import br.unipar.exemplo.rest.dto.ClienteRequest;
import br.unipar.exemplo.rest.exceptions.ValidacaoException;
import br.unipar.exemplo.rest.models.Cliente;
import br.unipar.exemplo.rest.services.ClienteService;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.net.URI;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;

/**
 *
 * @author 
 */
@Path("cliente")
@Produces(MediaType.APPLICATION_JSON)//converter automaticamente o tipo
public class ClienteController {
    
//    @GET  //verbo http que indica busca de informações
//    @Path(value = "ping")//criando path especifica para o método/ não é obrigatório usar "value"
//    public Response ping(){
//        return Response
//                .ok("pong")
//                .build();
//    }
//    
//    @GET
//    @Path("pong")
//    public Response pong(){
//        return Response
//                .ok("ping")
//                .build();//gerencia as respostas e type da resposta
//    }
    
//    @GET
//    @Path("{nome}")//depois do cliente vai o nome - .../cliente/nome - {} vai passar um parâmetro dentro da url
//    public String getNomeCliente(@PathParam("nome") String nmCliente) {//@PathParam - vai receber na url e jogar no parâmetro
//        System.out.println(nmCliente);
//        return nmCliente;
//    }
    
    //C @POST
    //R @GET
    //U @PUT
    //D @Delete
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)//vai pegar as propriedades do json, fazer um binde dos objetos e converter para json
    public Response insert(ClienteRequest cliente) throws 
            ValidacaoException, 
            SQLException, 
            NamingException{
        
        try {
            
        
        ClienteService clienteService = new ClienteService();
        Cliente clienteDomain = clienteService.insert(Cliente.
                requestToCliente(cliente));
        
        //passar pela camada de service
        return Response.created(
                URI.create("http://localhost:8080/exemplo-rest/cliente/"+
                        clienteDomain.getId())).build();
        
        //da exceção mais especifica para a menos
        } catch(ValidacaoException validacaoException) {
            return Response.status(Response.Status.BAD_REQUEST).
                    entity(validacaoException).build();
        } catch(SQLException | NamingException ex) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).
                    entity(new ValidacaoException("Ops, algo ocorreu de errado, "
                            + "tente novamente mais tarde")).build();
        } catch(Exception ex) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).
                    entity(new ValidacaoException("Erro desconhecido entre em contato "
                            + " com o suporte")).build();
        }
        //criar dto para a exceção cpf
    }
    
    @GET
    @Path("{id}")
    public Cliente findById(@PathParam("id") int id) {
        return new Cliente(id, "Beatriz", "987347238472");
    }
    
    //@QueryParam("nome") @DefaultValue("bia") String nome
    @GET
    public List<ClienteFindAllResponse> findAll(
            @QueryParam("id") int id,
            @QueryParam("nome") String nome){//...cliente?nome=bia
        
        ArrayList<ClienteFindAllResponse> listaClientes = new ArrayList<>();
        listaClientes.add(new ClienteFindAllResponse(1, "teste1"));
        listaClientes.add(new ClienteFindAllResponse(2, "teste2"));
        listaClientes.add(new ClienteFindAllResponse(3, "teste3"));
        
        return listaClientes;
        //@DefaultValue - colocar valor padrão
        //...cliente?nome=bia&cpf=123455667 - '&' usado para separar
    }
    
    @PUT
    @Path("{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Cliente edit(@PathParam("id") int id, Cliente cliente){
        return cliente;
    }
    
    @DELETE
    @Path("{id}")
    public void delete(@PathParam("id") int id){
        
    }
    
}
