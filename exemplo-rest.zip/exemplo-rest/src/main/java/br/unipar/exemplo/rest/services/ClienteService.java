/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.exemplo.rest.services;

import br.unipar.exemplo.rest.dto.ExceptionResponse;
import br.unipar.exemplo.rest.exceptions.ValidacaoException;
import br.unipar.exemplo.rest.models.Cliente;
import br.unipar.exemplo.rest.repositories.ClienteRepository;
import jakarta.ws.rs.core.Response;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import javax.naming.NamingException;

/**
 *
 * @author Beatr
 */
public class ClienteService {
    
    public Cliente insert(Cliente cliente) throws 
            ValidacaoException, 
            SQLException, 
            NamingException {
        
        //validar os dados
        ExceptionResponse exceptionResponse = new ExceptionResponse();
        
        if(cliente.getCpf().isEmpty())
            exceptionResponse.setMessage("Cpf não pode ser vazio");
            exceptionResponse.setDtException(Date.valueOf(LocalDate.now()));
            exceptionResponse.setPath("/");
            exceptionResponse.setHttpStatus(Response.Status.BAD_REQUEST);
            
            //throw new ValidacaoException("Cpf não pode ser vazio");
        
        if(cliente.getCpf().trim().length() != 11)
            exceptionResponse.setMessage("Valor do Cpf informado invalido");
            exceptionResponse.setDtException(Date.valueOf(LocalDate.now()));
            exceptionResponse.setPath("/");
            exceptionResponse.setHttpStatus(Response.Status.BAD_REQUEST);
            //throw new ValidacaoException("Valor do Cpf informado invalido");
        
        if(cliente.getNome().trim().isEmpty())//trim() - tira o espaço vazio
            exceptionResponse.setMessage("Nome não pode ser vazio");
            exceptionResponse.setDtException(Date.valueOf(LocalDate.now()));
            exceptionResponse.setPath("/");
            exceptionResponse.setHttpStatus(Response.Status.BAD_REQUEST);
            //throw new ValidacaoException("Nome não pode ser vazio");
        
        //chamar o Repositorio;
        return new ClienteRepository().insert(cliente);
        
    }
    
}
